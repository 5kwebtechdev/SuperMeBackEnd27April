package com.superme.controller;

import com.superme.dto.*;
import com.superme.service.UserCartService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cart")
@RequiredArgsConstructor
public class UserCartController {

    private final UserCartService userCartService;

    // Cart is scoped to user + school + class
    @GetMapping
    public CartSummaryDto getCart(@RequestParam Long schoolId,
                                  @RequestParam List<String> className) {
        return userCartService.getCart(schoolId, className);
    }

    @PostMapping("/items")
    public CartSummaryDto addItem(@RequestBody AddToCartRequest request) {
        return userCartService.addItem(request);
    }

    @PutMapping("/items/{itemId}")
    public CartSummaryDto updateItem(@PathVariable Long itemId,
                                     @RequestBody UpdateCartItemRequest request) {
        return userCartService.updateItem(itemId, request);
    }

    @DeleteMapping("/items/{itemId}")
    public CartSummaryDto removeItem(@PathVariable Long itemId) {
        return userCartService.removeItem(itemId);
    }

    @DeleteMapping
    public void clearCart(@RequestParam Long schoolId,
                          @RequestParam List<String> className) {
        userCartService.clearCart(schoolId, className);
    }
}
