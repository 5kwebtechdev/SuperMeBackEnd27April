package com.superme.controller;

import com.superme.dto.CategoryResponseDTO;
import com.superme.service.AcademicCategoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/category")
@RequiredArgsConstructor
public class AcademicCategoryController {

    private final AcademicCategoryService academicCategoryService;

    @Operation(
            summary = "Get all active categories",
            description = "Returns all active categories for users. Requires user authentication token.",
            security = @SecurityRequirement(name = "bearerAuth")
    )
    @GetMapping
    @PreAuthorize("hasAnyRole('USER', 'ADMIN', 'SUPER_ADMIN')")
    public ResponseEntity<List<CategoryResponseDTO>> getActiveCategories() {
        List<CategoryResponseDTO> categories = academicCategoryService.getActiveCategories();
        return ResponseEntity.ok(categories);
    }
}