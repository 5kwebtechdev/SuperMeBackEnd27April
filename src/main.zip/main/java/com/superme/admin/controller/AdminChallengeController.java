package com.superme.admin.controller;

import com.superme.dto.*;
import com.superme.enums.*;
import com.superme.exception.BusinessException;
import com.superme.exception.ResourceNotFoundException;
import com.superme.service.AdminChallengeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Merged & optimized AdminChallengeController
 *
 * - Keeps latest DTOs (MultiQuestionChallengeRequestDTO / ResponseDTO)
 * - Adds analytics, overview, search, filter-options, export, bulk operations
 * - Uses ResponseEntity with consistent response map payloads
 */
@RestController
@RequestMapping("/admin/challenges")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class AdminChallengeController {

    private final AdminChallengeService adminChallengeService;

    // -----------------------
    // CREATE / BULK CREATE
    // -----------------------
    @PostMapping("/add")
    public ResponseEntity<Map<String, Object>> createChallenge(
            @RequestBody MultiQuestionChallengeRequestDTO request) {

        Map<String, Object> response = new HashMap<>();
        try {
            MultiQuestionChallengeResponseDTO created = adminChallengeService.createChallenge(request);
            response.put("success", true);
            response.put("message", "Challenge created successfully");
            response.put("data", created);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (BusinessException e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "Failed to create challenge: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/bulk-add")
    public ResponseEntity<Map<String, Object>> bulkAddChallenge(@RequestBody List<MultiQuestionChallengeRequestDTO> challengeDTOs) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<MultiQuestionChallengeResponseDTO> savedList = adminChallengeService.addChallengeList(challengeDTOs);
            response.put("success", true);
            response.put("message", "Challenges added successfully");
            response.put("challenges", savedList);
            response.put("count", savedList.size());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // -----------------------
    // READ (single / all)
    // -----------------------
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getChallenge(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            MultiQuestionChallengeResponseDTO challenge = adminChallengeService.getChallengeById(id);
            response.put("success", true);
            response.put("data", challenge);
            return ResponseEntity.ok(response);
        } catch (ResourceNotFoundException e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "Failed to get challenge: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping
    public ResponseEntity<Map<String, Object>> getAllChallenges() {
        Map<String, Object> response = new HashMap<>();
        try {
            List<MultiQuestionChallengeResponseDTO> challenges = adminChallengeService.getAllChallenges();
            response.put("success", true);
            response.put("data", challenges);
            response.put("count", challenges.size());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "Failed to get challenges: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // -----------------------
    // UPDATE
    // -----------------------
    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updateChallenge(
            @PathVariable Long id,
            @RequestBody MultiQuestionChallengeRequestDTO request) {

        Map<String, Object> response = new HashMap<>();
        try {
            MultiQuestionChallengeResponseDTO updated = adminChallengeService.updateChallenge(id, request);
            response.put("success", true);
            response.put("message", "Challenge updated successfully");
            response.put("data", updated);
            return ResponseEntity.ok(response);
        } catch (ResourceNotFoundException e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (BusinessException e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "Failed to update challenge: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // -----------------------
    // SOFT DELETE / BULK DELETE
    // -----------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> deleteChallenge(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            adminChallengeService.softDeleteChallenge(id);
            response.put("success", true);
            response.put("message", "Challenge deleted successfully");
            return ResponseEntity.ok(response);
        } catch (ResourceNotFoundException e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        } catch (BusinessException e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "Failed to delete challenge: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PutMapping("/bulk-delete")
    public ResponseEntity<Map<String, Object>> bulkDeleteChallenges(@RequestParam List<Long> challengeIds) {
        Map<String, Object> response = new HashMap<>();
        try {
            adminChallengeService.bulkDeleteChallenges(challengeIds);
            response.put("success", true);
            response.put("message", "Deleted " + challengeIds.size() + " challenges");
            response.put("deletedCount", challengeIds.size());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // -----------------------
    // STATUS update (single + bulk)
    // -----------------------
    @PatchMapping("/{id}/status")
    public ResponseEntity<Map<String, Object>> updateChallengeStatus(
            @PathVariable Long id,
            @RequestParam String status) {

        Map<String, Object> response = new HashMap<>();
        try {
            // fetch existing to build update DTO (to reuse existing fields)
            MultiQuestionChallengeResponseDTO existing = adminChallengeService.getChallengeById(id);

            MultiQuestionChallengeRequestDTO updateRequest = MultiQuestionChallengeRequestDTO.builder()
                    .name(existing.getName())
                    .description(existing.getDescription())
                    .descriptionExpanded(existing.getDescriptionExpanded())
                    .category(existing.getCategory())
                    .difficulty(existing.getDifficulty())
                    .ageGroups(existing.getAgeGroups())
                    .topic(existing.getTopic())
                    .status(Status.valueOf(status.toUpperCase()))
                    .coins(existing.getCoins())
                    .coinsForCorrectAnswer(existing.getCoinsForCorrectAnswer())
                    .trophies(existing.getTrophies())
                    .timeDuration(existing.getTimeDuration())
                    .sectionTitle(existing.getSectionTitle())
                    .positiveFeedback(existing.getPositiveFeedback())
                    .negativeFeedback(existing.getNegativeFeedback())
                    .negativeFeedbackTryAgain(existing.getNegativeFeedbackTryAgain())
                    .thumbnailImageUrl(existing.getThumbnailImageUrl())
                    .innerImageUrl(existing.getInnerImageUrl())
                    .enabled(existing.isEnabled())
                    .questions(existing.getQuestions().stream()
                            .map(this::convertToQuestionRequestDTO)
                            .collect(Collectors.toList()))
                    .attachments(existing.getAttachments() != null ?
                            existing.getAttachments().stream()
                                    .map(att -> ChallengeAttachmentRequestDTO.builder()
                                            .fileName(att.getFileName())
                                            .fileUrl(att.getFileUrl())
                                            .fileType(att.getFileType())
                                            .fileSize(att.getFileSize())
                                            .build())
                                    .collect(Collectors.toList()) : null)
                    .build();

            MultiQuestionChallengeResponseDTO updated = adminChallengeService.updateChallenge(id, updateRequest);

            response.put("success", true);
            response.put("message", "Challenge status updated successfully");
            response.put("data", updated);
            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("error", "Invalid status. Allowed: " + Arrays.toString(Status.values()));
            return ResponseEntity.badRequest().body(response);
        } catch (ResourceNotFoundException e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        } catch (BusinessException e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "Failed to update challenge status: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PutMapping("/bulk-update-status")
    public ResponseEntity<Map<String, Object>> bulkUpdateChallengeStatus(
            @RequestParam List<Long> challengeIds,
            @RequestParam Status status) {

        Map<String, Object> response = new HashMap<>();
        try {
            adminChallengeService.bulkUpdateStatus(challengeIds, status);
            response.put("success", true);
            response.put("message", "Updated status for " + challengeIds.size() + " challenges");
            response.put("updatedCount", challengeIds.size());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // -----------------------
    // OVERVIEW (FILTERING + PAGINATION)
    // -----------------------
    @GetMapping("/overview")
    public ResponseEntity<?> getAllChallengeViews(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String difficulty,
            @RequestParam(required = false) String ageGroup,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String answerType,
            @RequestParam(required = false) Boolean enabled,
            @RequestParam(required = false) Integer minQuestions,
            @RequestParam(required = false) Integer maxQuestions,
            @RequestParam(required = false) Boolean hasHint,
            @RequestParam(required = false) Boolean hasAttachments,
            @RequestParam(required = false) Boolean hasImageQuestion,
            @RequestParam(required = false) Boolean hasImageOptions,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {

        try {
            // retrieve all views (service implementation can fetch DTOs)
            List<AdminChallengeDTO> challenges = adminChallengeService.getAllChallengeViews();
            ChallengeStatsResponse stats = adminChallengeService.getDashboardStats();

            AdminChallengeDTO.ChallengeFilterCriteria criteria = new AdminChallengeDTO.ChallengeFilterCriteria();
            criteria.setSearchTerm(search);
            criteria.setType(type);
            criteria.setDifficulty(difficulty);
            criteria.setAgeGroup(ageGroup);
            criteria.setStatus(status);
            criteria.setAnswerType(answerType);
            criteria.setEnabled(enabled);

            List<AdminChallengeDTO> filtered = challenges.stream()
                    .filter(c -> (search == null || c.matchesSearchTerm(search)))
                    .filter(c -> (type == null || (c.getTypeValue() != null && c.getTypeValue().equalsIgnoreCase(type))))
                    .filter(c -> (difficulty == null || (c.getDifficultyValue() != null && c.getDifficultyValue().equalsIgnoreCase(difficulty))))
                    .filter(c -> (ageGroup == null || (c.getAgeGroups() != null &&
                            c.getAgeGroups().stream().anyMatch(ag -> ag.name().equalsIgnoreCase(ageGroup)))))
                    .filter(c -> (status == null || (c.getStatus() != null && c.getStatus().name().equalsIgnoreCase(status))))
                    .filter(c -> (answerType == null || (c.getAnswerTypes() != null &&
                            c.getAnswerTypes().stream().anyMatch(at -> at.name().equalsIgnoreCase(answerType)))))
                    .filter(c -> minQuestions == null || c.getNumberOfQuestions() >= minQuestions)
                    .filter(c -> maxQuestions == null || c.getNumberOfQuestions() <= maxQuestions)
                    .filter(c -> hasHint == null
                            || (hasHint && c.getHint() != null && !c.getHint().trim().isEmpty())
                            || (!hasHint && (c.getHint() == null || c.getHint().trim().isEmpty())))
                    .filter(c -> hasAttachments == null || c.isHasAttachments() == hasAttachments)
                    .filter(c -> hasImageQuestion == null || c.isHasImageQuestion() == hasImageQuestion)
                    .filter(c -> hasImageOptions == null || c.isHasImageOptions() == hasImageOptions)
                    .filter(c -> enabled == null || c.isEnabled() == enabled)
                    .collect(Collectors.toList());

            int totalCount = filtered.size();
            int start = Math.min(page * size, totalCount);
            int end = Math.min(start + size, totalCount);
            List<AdminChallengeDTO> paginated = filtered.subList(start, end);

            Map<String, Object> payload = new HashMap<>();
            payload.put("success", true);
            payload.put("data", paginated);
            payload.put("criteria", criteria);
            payload.put("totalAll", challenges.size());
            payload.put("totalFiltered", filtered.size());
            Map<String, Object> pagination = new HashMap<>();
            pagination.put("page", page + 1);
            pagination.put("size", size);
            pagination.put("total", totalCount);
            payload.put("pagination", pagination);
            payload.put("stats", stats);

            return ResponseEntity.ok(payload);
        } catch (Exception e) {
            Map<String, Object> err = new HashMap<>();
            err.put("success", false);
            err.put("error", "Failed to get overview: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(err);
        }
    }

    // -----------------------
    // QUICK STATS
    // -----------------------
    @GetMapping("/quick-stats")
    public ResponseEntity<Map<String, Object>> getQuickChallengeStats() {
        Map<String, Object> response = new HashMap<>();
        try {
            ChallengeStatsResponse stats = adminChallengeService.getDashboardStats();
            response.put("success", true);
            response.put("totalChallenges", stats.getTotalChallenges());
            response.put("totalChallengesPublished", stats.getTotalChallengesPublished());
            response.put("totalDrafts", stats.getTotalDrafts());
            response.put("totalUnderReview", stats.getTotalUnderReview());
            response.put("averageCompletionRate", stats.getAverageCompletionRate());
            response.put("timestamp", System.currentTimeMillis());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // -----------------------
    // SEARCH (simple)
    // -----------------------
    @GetMapping("/search")
    public ResponseEntity<Map<String, Object>> searchChallenges(
            @RequestParam("q") String query,
            @RequestParam(defaultValue = "20") int limit,
            @RequestParam(defaultValue = "0") int offset) {

        Map<String, Object> response = new HashMap<>();
        try {
            List<AdminChallengeDTO> all = adminChallengeService.getAllChallengeViews();
            List<AdminChallengeDTO> results = all.stream()
                    .filter(c -> c.matchesSearchTerm(query))
                    .collect(Collectors.toList());

            int start = Math.max(0, offset);
            int end = Math.min(results.size(), start + limit);
            List<AdminChallengeDTO> paginated = start < results.size() ? results.subList(start, end) : Collections.emptyList();

            response.put("success", true);
            response.put("challenges", paginated);
            response.put("totalCount", results.size());
            response.put("limit", limit);
            response.put("offset", offset);
            response.put("hasMore", (offset + limit) < results.size());
            response.put("searchTerm", query);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // -----------------------
    // FILTER OPTIONS
    // -----------------------
    @GetMapping("/filter-options")
    public ResponseEntity<Map<String, Object>> getChallengeFilterOptions() {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("success", true);
            response.put("types", adminChallengeService.getAvailableTypes());
            response.put("difficulties", adminChallengeService.getAvailableDifficulties());
            response.put("ageGroups", adminChallengeService.getAvailableAgeGroups());
            response.put("answerTypes", adminChallengeService.getAvailableAnswerTypes());
            response.put("statuses", adminChallengeService.getAvailableStatuses());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // -----------------------
    // ANALYTICS & BREAKDOWNS
    // -----------------------
    @GetMapping("/analytics")
    public ResponseEntity<Map<String, Object>> getChallengeAnalytics() {
        Map<String, Object> response = new HashMap<>();
        try {
            ChallengeStatsResponse stats = adminChallengeService.getDashboardStats();
            Map<String, Object> breakdowns = adminChallengeService.getChallengeBreakdowns();

            response.put("success", true);
            response.put("statistics", stats);
            response.put("categoryBreakdown", breakdowns.get("categoryBreakdown"));
            response.put("difficultyBreakdown", breakdowns.get("difficultyBreakdown"));
            response.put("ageGroupBreakdown", breakdowns.get("ageGroupBreakdown"));
            response.put("answerTypeBreakdown", breakdowns.get("answerTypeBreakdown"));
            response.put("questionsDistribution", breakdowns.get("questionsDistribution"));
            response.put("completionStats", breakdowns.get("completionStats"));
            response.put("timestamp", System.currentTimeMillis());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // -----------------------
    // EXPORT
    // -----------------------
    @GetMapping("/export")
    public ResponseEntity<Map<String, Object>> exportChallengeData(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String difficulty,
            @RequestParam(required = false) String ageGroup,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String answerType,
            @RequestParam(defaultValue = "csv") String format) {

        Map<String, Object> response = new HashMap<>();
        try {
            AdminChallengeDTO.ChallengeFilterCriteria criteria = new AdminChallengeDTO.ChallengeFilterCriteria();
            criteria.setSearchTerm(search);
            criteria.setType(type);
            criteria.setDifficulty(difficulty);
            criteria.setAgeGroup(ageGroup);
            criteria.setStatus(status);
            criteria.setAnswerType(answerType);

            String exportData = adminChallengeService.exportChallengeData(criteria, format);

            response.put("success", true);
            response.put("data", exportData);
            response.put("format", format);
            response.put("filename", "challenges_export_" + System.currentTimeMillis() + "." + format);
            response.put("criteria", criteria);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // -----------------------
    // HEALTH / STATUS
    // -----------------------
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getChallengeServiceStatus() {
        Map<String, Object> response = new HashMap<>();
        try {
            ChallengeStatsResponse stats = adminChallengeService.getDashboardStats();
            response.put("success", true);
            response.put("status", "healthy");
            response.put("totalChallenges", stats.getTotalChallenges());
            response.put("serviceVersion", "2.0");
            response.put("timestamp", System.currentTimeMillis());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("status", "error");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // -----------------------
    // Helper: convert QuestionResponseDTO -> QuestionRequestDTO
    // -----------------------
    private QuestionRequestDTO convertToQuestionRequestDTO(QuestionResponseDTO responseDTO) {
        if (responseDTO == null) return null;
        List<QuestionOptionRequestDTO> opts = responseDTO.getOptions() == null ? Collections.emptyList()
                : responseDTO.getOptions().stream()
                .map(opt -> QuestionOptionRequestDTO.builder()
                        .optionText(opt.getOptionText())
                        .optionImageUrl(opt.getOptionImageUrl())
                        .optionOrder(opt.getOptionOrder())
                        .isCorrect(opt.getIsCorrect())
                        .explanation(opt.getExplanation())
                        .build())
                .collect(Collectors.toList());

        return QuestionRequestDTO.builder()
                .questionOrder(responseDTO.getQuestionOrder())
                .questionText(responseDTO.getQuestionText())
                .questionImageUrl(responseDTO.getQuestionImageUrl())
                .hint(responseDTO.getHint())
                .answerType(responseDTO.getAnswerType())
                .points(responseDTO.getPoints())
                .timeLimit(responseDTO.getTimeLimit())
                .attachmentUrl(responseDTO.getAttachmentUrl())
                .attachmentType(responseDTO.getAttachmentType())
                .options(opts)
                .build();
    }
}