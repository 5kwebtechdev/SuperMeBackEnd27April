package com.superme.admin.controller;

import com.superme.dto.AdminTutorDTO;
import com.superme.dto.AdminTutorDTO.TutorStatistics;
import com.superme.dto.AdminTutorOverviewResponseDTO;
import com.superme.dto.TutorDto;
import com.superme.model.Tutor;
import com.superme.service.AdminTutorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Admin controller for tutor management operations with enhanced screen functionality.
 * Includes data table, stat cards, search bar, and filters for admin tutor screen.
 */
@RestController
@RequestMapping("/admin/tutors")
@CrossOrigin(origins = "*")
public class AdminTutorController {

    @Autowired
    private AdminTutorService adminTutorService;

    // ============================================================================
    // ADMIN TUTOR SCREEN MAIN ENDPOINT
    // ============================================================================

    /**
     * Get complete admin tutor overview with data table, stats, and filters
     * This is the main endpoint for the admin tutor screen
     */
    // ================== OVERVIEW ==================
    @GetMapping("/overview")
    public ResponseEntity<?> getAdminTutorOverview(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir,
            // Search parameters
            @RequestParam(required = false) String searchName,
            @RequestParam(required = false) String searchHeadline,   // <-- NEW
            @RequestParam(required = false) Integer searchAge,
            @RequestParam(required = false) String searchPhone,
            @RequestParam(required = false) List<Tutor.Subject> searchSubjects,
            @RequestParam(required = false) Tutor.Experience searchExperience,
            @RequestParam(required = false) String searchQualification,
            @RequestParam(required = false) Tutor.Gender searchGender,
            @RequestParam(required = false) String searchLocation,
            // Filter parameters
            @RequestParam(required = false) List<Tutor.Experience> filterExperience,
            @RequestParam(required = false) List<String> filterQualification,
            @RequestParam(required = false) List<Tutor.Subject> filterSubjects,
            @RequestParam(required = false) List<String> filterLocation) {
        try {
            AdminTutorOverviewResponseDTO overview = adminTutorService.getAdminTutorOverview(
                    page, size, sortBy, sortDir,
                    searchName, searchHeadline, searchAge, searchPhone,      // <-- pass searchHeadline
                    searchSubjects, searchExperience, searchQualification,
                    searchGender, searchLocation,
                    filterExperience, filterQualification, filterSubjects, filterLocation
            );

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "data", overview
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                    "success", false,
                    "message", "Failed to fetch tutor overview: " + e.getMessage()
            ));
        }
    }


    /**
     * Get data table only for tutors with search and filters (Specification-based, DB-side filtering)
     */
    // ================== DATA TABLE ==================
    @GetMapping("/datatable")
    public ResponseEntity<?> getTutorDataTable(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir,
            // Search parameters
            @RequestParam(required = false) String searchName,
            @RequestParam(required = false) String searchHeadline,   // <-- NEW
            @RequestParam(required = false) Integer searchAge,
            @RequestParam(required = false) String searchPhone,
            @RequestParam(required = false) List<Tutor.Subject> searchSubjects,
            @RequestParam(required = false) Tutor.Experience searchExperience,
            @RequestParam(required = false) String searchQualification,
            @RequestParam(required = false) Tutor.Gender searchGender,
            @RequestParam(required = false) String searchLocation,
            // Filter parameters
            @RequestParam(required = false) List<Tutor.Experience> filterExperience,
            @RequestParam(required = false) List<String> filterQualification,
            @RequestParam(required = false) List<Tutor.Subject> filterSubjects,
            @RequestParam(required = false) List<String> filterLocation) {
        try {
            Page<AdminTutorDTO> tutorDataTable = adminTutorService.getTutorDataTable(
                    page, size, sortBy, sortDir,
                    searchName, searchHeadline, searchAge, searchPhone,      // <-- pass searchHeadline
                    searchSubjects, searchExperience, searchQualification,
                    searchGender, searchLocation,
                    filterExperience, filterQualification, filterSubjects, filterLocation
            );

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "data", tutorDataTable.getContent(),
                    "pagination", Map.of(
                            "currentPage", tutorDataTable.getNumber(),
                            "totalPages", tutorDataTable.getTotalPages(),
                            "totalElements", tutorDataTable.getTotalElements(),
                            "size", tutorDataTable.getSize(),
                            "hasNext", tutorDataTable.hasNext(),
                            "hasPrevious", tutorDataTable.hasPrevious()
                    )
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                    "success", false,
                    "message", "Failed to fetch tutor data table: " + e.getMessage()
            ));
        }
    }


    /**
     * Get stat cards for admin tutor screen
     */
    @GetMapping("/stats")
    public ResponseEntity<?> getTutorStats() {
        try {
            Map<String, Object> stats = adminTutorService.getTutorStatsForCards();
            return ResponseEntity.ok(Map.of(
                "success", true,
                "data", stats
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to fetch tutor stats: " + e.getMessage()
            ));
        }
    }

    /**
     * Get search suggestions for search bar
     */
    @GetMapping("/search-suggestions")
    public ResponseEntity<?> getSearchSuggestions(@RequestParam String query, @RequestParam String type) {
        try {
            List<String> suggestions = adminTutorService.getSearchSuggestions(query, type);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "data", suggestions
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to fetch search suggestions: " + e.getMessage()
            ));
        }
    }

    /**
     * Get filter options for filter dropdowns
     */
    @GetMapping("/filter-options")
    public ResponseEntity<?> getFilterOptions() {
        try {
            // Get empty list since we need it for the service call
            List<AdminTutorDTO> emptyList = List.of();
            Map<String, Object> filterOptions = adminTutorService.getFilterOptions(emptyList);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "data", filterOptions
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to fetch filter options: " + e.getMessage()
            ));
        }
    }

    // ============================================================================
    // CRUD OPERATIONS
    // ============================================================================

    /**
     * Create a new tutor
     */
    @PostMapping("/add")
    public ResponseEntity<?> createTutor(@RequestBody TutorDto tutor) {
        try {
            Tutor createdTutor = adminTutorService.createTutor(tutor);
            return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                "success", true,
                "message", "Tutor created successfully",
                "data", createdTutor
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of(
                "success", false,
                "message", "Failed to create tutor: " + e.getMessage()
            ));
        }
    }

    @PostMapping("/bulk-add")
    public ResponseEntity<?> createTutors(@RequestBody List<TutorDto> tutors) {
        try {
            List<Tutor> createdTutors = adminTutorService.createTutors(tutors);
            return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                    "success", true,
                    "message", "Tutors created successfully",
                    "count", createdTutors.size()
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of(
                    "success", false,
                    "message", "Failed to create tutors: " + e.getMessage()
            ));
        }
    }

    /**
     * Get all tutors with pagination
     */
    @GetMapping
    public ResponseEntity<?> getAllTutors(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir) {
        try {
            Page<Tutor> tutorsPage = adminTutorService.getAllTutors(page, size, sortBy, sortDir);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "data", tutorsPage.getContent(),
                "pagination", Map.of(
                    "currentPage", tutorsPage.getNumber(),
                    "totalPages", tutorsPage.getTotalPages(),
                    "totalElements", tutorsPage.getTotalElements(),
                    "size", tutorsPage.getSize(),
                    "hasNext", tutorsPage.hasNext(),
                    "hasPrevious", tutorsPage.hasPrevious()
                )
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to fetch tutors: " + e.getMessage()
            ));
        }
    }

    /**
     * Get all tutors without pagination
     */
    @GetMapping("/all")
    public ResponseEntity<?> getAllTutorsNoPagination() {
        try {
            List<Tutor> tutors = adminTutorService.getAllTutors();
            return ResponseEntity.ok(Map.of(
                "success", true,
                "data", tutors,
                "count", tutors.size()
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to fetch tutors: " + e.getMessage()
            ));
        }
    }

    /**
     * Get tutor by ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getTutorById(@PathVariable Long id) {
        try {
            Optional<AdminTutorDTO> tutor = adminTutorService.getTutorById(id);
            if (tutor.isPresent()) {
                return ResponseEntity.ok(Map.of(
                    "success", true,
                    "data", tutor.get()
                ));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of(
                    "success", false,
                    "message", "Tutor not found with id: " + id
                ));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to fetch tutor: " + e.getMessage()
            ));
        }
    }

    /**
     * Update tutor
     */
    @PutMapping("/update")
    public ResponseEntity<?> updateTutor(@RequestBody TutorDto tutorDto) {
        adminTutorService.updateTutor(tutorDto);
        return ResponseEntity.ok().body(Map.of(
                "status", "success",
                "message", "Tutor updated successfully",
                "tutorId", tutorDto.getId()
        ));
    }

    /**
     * Soft delete a tutor by ID
     *
     * @param id Tutor ID
     * @return ResponseEntity with status
     */
    @DeleteMapping("/delete")
    public ResponseEntity<?> deleteTutor(@RequestParam Long id) {
        adminTutorService.deleteTutor(id);
        return ResponseEntity.ok().body(Map.of(
                "status", "success",
                "message", "Tutor soft-deleted successfully",
                "tutorId", id
        ));
    }

    // ============================================================================
    // STATUS MANAGEMENT
    // ============================================================================

    /**
     * Activate a tutor by ID using request param
     *
     * @param id Tutor ID as request parameter
     * @return ResponseEntity with status
     */
    @PatchMapping("/activate")
    public ResponseEntity<?> activateTutor(@RequestParam Long id) {
        adminTutorService.activateTutor(id);
        return ResponseEntity.ok().body(Map.of(
                "status", "success",
                "message", "Tutor activated successfully",
                "tutorId", id
        ));
    }

    /**
     * Deactivate tutor
     */
    @PatchMapping("/{id}/deactivate")
    public ResponseEntity<?> deactivateTutor(@PathVariable Long id) {
        try {
            Tutor tutor = adminTutorService.deactivateTutor(id);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Tutor deactivated successfully",
                "data", tutor
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of(
                "success", false,
                "message", "Failed to deactivate tutor: " + e.getMessage()
            ));
        }
    }

    /**
     * Verify tutor
     */
    @PutMapping("/verify")
    public ResponseEntity<?> verifyTutor(@RequestParam Long id) {
        Tutor tutor = adminTutorService.verifyTutor(id);
        return ResponseEntity.ok().body(Map.of(
                "status", "success",
                "message", "Tutor verified successfully",
                "tutorId", id
        ));
    }

    /**
     * Unverify tutor
     */
    @PutMapping("/unverify")
    public ResponseEntity<?> unverifyTutor(@RequestParam Long id) {
        Tutor tutor = adminTutorService.unverifyTutor(id);
        return ResponseEntity.ok().body(Map.of(
                "status", "success",
                "message", "Tutor unverified  successfully",
                "tutorId", id
        ));
    }

    // ============================================================================
    // FILE UPLOAD OPERATIONS
    // ============================================================================

    /**
     * Upload profile picture
     */
    @PostMapping("/{id}/profile-picture")
    public ResponseEntity<?> uploadProfilePicture(@PathVariable Long id, @RequestParam("file") MultipartFile file) {
        try {
            if (file.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of(
                    "success", false,
                    "message", "Please select a file to upload"
                ));
            }

            String fileUrl = adminTutorService.uploadProfilePicture(id, file);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Profile picture uploaded successfully",
                "fileUrl", fileUrl
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to upload profile picture: " + e.getMessage()
            ));
        }
    }

    /**
     * Upload verification documents
     */
    @PostMapping("/{id}/verification-documents")
    public ResponseEntity<?> uploadVerificationDocuments(@PathVariable Long id, @RequestParam("file") MultipartFile file) {
        try {
            if (file.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of(
                    "success", false,
                    "message", "Please select a file to upload"
                ));
            }

            String fileUrl = adminTutorService.uploadVerificationDocuments(id, file);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Verification documents uploaded successfully",
                "fileUrl", fileUrl
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to upload verification documents: " + e.getMessage()
            ));
        }
    }

    // ============================================================================
    // SEARCH AND FILTER OPERATIONS
    // ============================================================================

    /**
     * Search tutors with legacy endpoint
     */
    @GetMapping("/search")
    public ResponseEntity<?> searchTutors(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) Tutor.Gender gender,
            @RequestParam(required = false) Tutor.Experience experience,
            @RequestParam(required = false) Tutor.EntityType entityType,
            @RequestParam(required = false) Boolean isActive,
            @RequestParam(required = false) Boolean isVerified) {
        try {
            List<Tutor> tutors = adminTutorService.searchTutors(name);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "data", tutors,
                "count", tutors.size()
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to search tutors: " + e.getMessage()
            ));
        }
    }

    /**
     * Get tutors by status
     */
    @GetMapping("/by-status")
    public ResponseEntity<?> getTutorsByStatus(
            @RequestParam(required = false) Boolean isActive,
            @RequestParam(required = false) Boolean isVerified) {
        try {
            List<Tutor> tutors = adminTutorService.getTutorsByStatus(isActive);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "data", tutors,
                "count", tutors.size()
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to fetch tutors by status: " + e.getMessage()
            ));
        }
    }

    /**
     * Get tutors by subjects filter (new endpoint, uses valid repository/service method)
     */
    @GetMapping("/by-subjects")
    public ResponseEntity<?> getTutorsBySubjects(@RequestParam List<Tutor.Subject> subjects) {
        try {
            List<Tutor> tutors = adminTutorService.getTutorsBySubjects(subjects);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "data", tutors,
                "count", tutors.size()
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to fetch tutors by subjects: " + e.getMessage()
            ));
        }
    }

    // ============================================================================
    // STATISTICS AND ANALYTICS
    // ============================================================================

    /**
     * Get tutor statistics (legacy)
     */
    @GetMapping("/statistics")
    public ResponseEntity<?> getTutorStatistics() {
        try {
            TutorStatistics stats = adminTutorService.getTutorStatistics();
            return ResponseEntity.ok(Map.of(
                "success", true,
                "data", stats
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to fetch tutor statistics: " + e.getMessage()
            ));
        }
    }

    /**
     * Get pending verification tutors
     */
    @GetMapping("/pending-verification")
    public ResponseEntity<?> getPendingVerificationTutors() {
        try {
            List<Tutor> tutors = adminTutorService.getPendingVerificationTutors();
            return ResponseEntity.ok(Map.of(
                "success", true,
                "data", tutors,
                "count", tutors.size()
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to fetch pending verification tutors: " + e.getMessage()
            ));
        }
    }

    /**
     * Get recently added tutors
     */
    @GetMapping("/recent")
    public ResponseEntity<?> getRecentlyAddedTutors(@RequestParam(defaultValue = "10") int limit) {
        try {
            List<Tutor> tutors = adminTutorService.getRecentlyAddedTutors(limit);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "data", tutors,
                "count", tutors.size()
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to fetch recent tutors: " + e.getMessage()
            ));
        }
    }

    // ============================================================================
    // UTILITY ENDPOINTS
    // ============================================================================

    /**
     * Get enum values for dropdowns
     */
    @GetMapping("/enums")
    public ResponseEntity<?> getEnumValues() {
        try {
            Map<String, Object> enums = adminTutorService.getEnumValues();
            return ResponseEntity.ok(Map.of(
                "success", true,
                "data", enums
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to fetch enum values: " + e.getMessage()
            ));
        }
    }

    /**
     * Bulk operations
     */
    @PatchMapping("/bulk/activate")
    public ResponseEntity<?> bulkActivateTutors(@RequestBody List<Long> tutorIds) {
        try {
            int activated = 0;
            for (Long id : tutorIds) {
                try {
                    adminTutorService.activateTutor(id);
                    activated++;
                } catch (Exception e) {
                    // Continue with other IDs
                }
            }
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", activated + " tutors activated successfully",
                "activatedCount", activated
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to bulk activate tutors: " + e.getMessage()
            ));
        }
    }

    @PatchMapping("/bulk/deactivate")
    public ResponseEntity<?> bulkDeactivateTutors(@RequestBody List<Long> tutorIds) {
        try {
            int deactivated = 0;
            for (Long id : tutorIds) {
                try {
                    adminTutorService.deactivateTutor(id);
                    deactivated++;
                } catch (Exception e) {
                    // Continue with other IDs
                }
            }
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", deactivated + " tutors deactivated successfully",
                "deactivatedCount", deactivated
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "success", false,
                "message", "Failed to bulk deactivate tutors: " + e.getMessage()
            ));
        }
    }

    // ============================================================================
    // EXPORT OPERATIONS
    // ============================================================================

    /**
     * Export filtered tutor data
     */
    // ================== EXPORT ==================
    @GetMapping("/export")
    public ResponseEntity<?> exportTutorData(
            @RequestParam(defaultValue = "csv") String format,
            // Search parameters
            @RequestParam(required = false) String searchName,
            @RequestParam(required = false) String searchHeadline,   // <-- NEW
            @RequestParam(required = false) Integer searchAge,
            @RequestParam(required = false) String searchPhone,
            @RequestParam(required = false) List<Tutor.Subject> searchSubjects,
            @RequestParam(required = false) Tutor.Experience searchExperience,
            @RequestParam(required = false) String searchQualification,
            @RequestParam(required = false) Tutor.Gender searchGender,
            @RequestParam(required = false) String searchLocation,
            // Filter parameters
            @RequestParam(required = false) List<Tutor.Experience> filterExperience,
            @RequestParam(required = false) List<String> filterQualification,
            @RequestParam(required = false) List<Tutor.Subject> filterSubjects,
            @RequestParam(required = false) List<String> filterLocation) {
        try {
            String exportData = adminTutorService.exportTutorData(
                    format, searchName, searchHeadline, searchAge, searchPhone,   // <-- pass searchHeadline
                    searchSubjects, searchExperience, searchQualification,
                    searchGender, searchLocation,
                    filterExperience, filterQualification, filterSubjects, filterLocation
            );

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "data", exportData,
                    "format", format
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                    "success", false,
                    "message", "Failed to export tutor data: " + e.getMessage()
            ));
        }
    }

}