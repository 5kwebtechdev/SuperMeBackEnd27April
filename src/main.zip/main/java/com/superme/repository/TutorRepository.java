
package com.superme.repository;

import com.superme.model.Tutor;
import org.springframework.beans.PropertyValues;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.superme.enums.FeeType;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface TutorRepository extends JpaRepository<Tutor, Long> {

        // Basic finder methods
        Optional<Tutor> findByEmail(String email);

        List<Tutor> findByIsActiveTrue();

        List<Tutor> findByIsVerifiedTrue();

        List<Tutor> findByIsActiveTrueAndIsVerifiedTrue();

        // Additional status methods for AdminTutorService
        List<Tutor> findByIsActive(Boolean isActive);

        List<Tutor> findByIsVerified(Boolean isVerified);

        List<Tutor> findByIsVerifiedFalse();

        // Count methods for AdminTutorService
        long countByIsActive(Boolean isActive);

        long countByIsVerified(Boolean isVerified);

        // Convenience methods
        default long countByIsActiveTrue() {
                return countByIsActive(true);
        }

        default long countByIsVerifiedTrue() {
                return countByIsVerified(true);
        }

        // Find by attributes
        List<Tutor> findByGender(Tutor.Gender gender);

        List<Tutor> findByExperience(Tutor.Experience experience);

        List<Tutor> findByEntityType(Tutor.EntityType entityType);

        List<Tutor> findByLocationContainingIgnoreCase(String location);

        // Find by subjects
        @Query("SELECT DISTINCT t FROM Tutor t JOIN t.subjects s WHERE s = :subject")
        List<Tutor> findBySubject(@Param("subject") Tutor.Subject subject);

        @Query("SELECT DISTINCT t FROM Tutor t JOIN t.subjects s WHERE s IN :subjects")
        List<Tutor> findBySubjectsIn(@Param("subjects") List<Tutor.Subject> subjects);

        // Find by availability
        @Query("SELECT DISTINCT t FROM Tutor t JOIN t.availability a WHERE a = :availability")
        List<Tutor> findByAvailability(@Param("availability") Tutor.Availability availability);

        @Query("SELECT DISTINCT t FROM Tutor t JOIN t.availability a WHERE a IN :availabilities")
        List<Tutor> findByAvailabilityIn(@Param("availabilities") List<Tutor.Availability> availabilities);

        // Find by contact modes
        @Query("SELECT DISTINCT t FROM Tutor t JOIN t.contactModes cm WHERE cm = :contactMode")
        List<Tutor> findByContactMode(@Param("contactMode") Tutor.ContactMode contactMode);

        // Find by hourly rate range
        List<Tutor> findByHourlyRateBetween(BigDecimal minRate, BigDecimal maxRate);

        List<Tutor> findByHourlyRateLessThanEqual(BigDecimal maxRate);

        List<Tutor> findByHourlyRateGreaterThanEqual(BigDecimal minRate);

        // Age-based queries
        List<Tutor> findByAgeBetween(Integer minAge, Integer maxAge);

        List<Tutor> findByAgeGreaterThanEqual(Integer minAge);

        // Complex search queries (renamed to avoid duplicate method name)
        @Query("SELECT t FROM Tutor t WHERE " +
                        "(:location IS NULL OR LOWER(t.location) LIKE LOWER(CONCAT('%', :location, '%'))) AND " +
                        "(:experience IS NULL OR t.experience = :experience) AND " +
                        "(:entityType IS NULL OR t.entityType = :entityType) AND " +
                        "(:minRate IS NULL OR t.hourlyRate >= :minRate) AND " +
                        "(:maxRate IS NULL OR t.hourlyRate <= :maxRate) AND " +
                        "t.isActive = true AND t.isVerified = true")
        List<Tutor> findTutorsWithAdvancedFilters(@Param("location") String location,
                        @Param("experience") Tutor.Experience experience,
                        @Param("entityType") Tutor.EntityType entityType,
                        @Param("minRate") BigDecimal minRate,
                        @Param("maxRate") BigDecimal maxRate);

        // Find tutors by multiple criteria for filtering (unique name)
        // @Query("SELECT t FROM Tutor t WHERE " +
        // "(:experiences IS NULL OR SIZE(:experiences) = 0 OR t.experience IN
        // :experiences) AND " +
        // "(:qualifications IS NULL OR SIZE(:qualifications) = 0 OR t.qualification IN
        // :qualifications) AND " +
        // "(:locations IS NULL OR SIZE(:locations) = 0 OR t.location IN :locations)")
        // List<Tutor> findTutorsByMultipleFilters(
        // @Param("experiences") List<Tutor.Experience> experiences,
        // @Param("qualifications") List<String> qualifications,
        // @Param("locations") List<String> locations
        // );

        // Enhanced search queries for AdminTutorService with pagination support
        @Query("SELECT t FROM Tutor t WHERE " +
                        "(:searchName IS NULL OR LOWER(t.name) LIKE LOWER(CONCAT('%', :searchName, '%'))) AND " +
                        "(:searchAge IS NULL OR t.age = :searchAge) AND " +
                        "(:searchPhone IS NULL OR t.phone LIKE CONCAT('%', :searchPhone, '%')) AND " +
                        "(:searchQualification IS NULL OR LOWER(t.qualification) LIKE LOWER(CONCAT('%', :searchQualification, '%'))) AND "
                        +
                        "(:searchExperience IS NULL OR t.experience = :searchExperience) AND " +
                        "(:searchGender IS NULL OR t.gender = :searchGender) AND " +
                        "(:searchLocation IS NULL OR LOWER(t.location) LIKE LOWER(CONCAT('%', :searchLocation, '%')))")
        List<Tutor> findTutorsWithSearchCriteria(
                        @Param("searchName") String searchName,
                        @Param("searchAge") Integer searchAge,
                        @Param("searchPhone") String searchPhone,
                        @Param("searchQualification") String searchQualification,
                        @Param("searchExperience") Tutor.Experience searchExperience,
                        @Param("searchGender") Tutor.Gender searchGender,
                        @Param("searchLocation") String searchLocation);

        // Statistics queries
        @Query("SELECT COUNT(t) FROM Tutor t WHERE t.isActive = true")
        Long countActiveTutors();

        @Query("SELECT COUNT(t) FROM Tutor t WHERE t.isVerified = true")
        Long countVerifiedTutors();

        @Query("SELECT COUNT(t) FROM Tutor t WHERE t.isActive = true AND t.isVerified = true")
        Long countActiveAndVerifiedTutors();

        @Query("SELECT t.experience, COUNT(t) FROM Tutor t WHERE t.isActive = true GROUP BY t.experience")
        List<Object[]> countTutorsByExperience();

        @Query("SELECT t.entityType, COUNT(t) FROM Tutor t WHERE t.isActive = true GROUP BY t.entityType")
        List<Object[]> countTutorsByEntityType();

        @Query("SELECT s, COUNT(t) FROM Tutor t JOIN t.subjects s WHERE t.isActive = true GROUP BY s")
        List<Object[]> countTutorsBySubject();

        // Verification and status queries
        List<Tutor> findByIsVerifiedFalseAndIsActiveTrue();

        List<Tutor> findByDocumentsVerificationUrlIsNotNull();

        List<Tutor> findByProfilePicUrlIsNotNull();

        // Search by name
        List<Tutor> findByNameContainingIgnoreCase(String name);

        // Entity-based queries
        List<Tutor> findByEntityNameContainingIgnoreCase(String entityName);

        List<Tutor> findByEntityTypeAndEntityNameContainingIgnoreCase(Tutor.EntityType entityType, String entityName);

        // Phone and email queries
        Optional<Tutor> findByPhone(String phone);

        boolean existsByEmail(String email);

        boolean existsByPhone(String phone);

        // Additional queries for admin operations
        @Query("SELECT DISTINCT t.qualification FROM Tutor t WHERE t.qualification IS NOT NULL AND t.isActive = true")
        List<String> findDistinctQualifications();

        @Query("SELECT DISTINCT t.location FROM Tutor t WHERE t.location IS NOT NULL AND t.isActive = true")
        List<String> findDistinctLocations();

        @Query("SELECT DISTINCT t.entityName FROM Tutor t WHERE t.entityName IS NOT NULL AND t.isActive = true")
        List<String> findDistinctEntityNames();

        // Bulk operations support
        @Query("SELECT t FROM Tutor t WHERE t.id IN :ids")
        List<Tutor> findByIdIn(@Param("ids") List<Long> ids);

        // Recent tutors query
        @Query("SELECT t FROM Tutor t ORDER BY t.createdAt DESC")
        List<Tutor> findRecentTutors();

        // Export queries
        @Query("SELECT t FROM Tutor t WHERE " +
                        "(:isActive IS NULL OR t.isActive = :isActive) AND " +
                        "(:isVerified IS NULL OR t.isVerified = :isVerified)")
        List<Tutor> findTutorsForExport(
                        @Param("isActive") Boolean isActive,
                        @Param("isVerified") Boolean isVerified);

        // Advanced search with multiple parameters
        @Query("SELECT t FROM Tutor t WHERE " +
                        "(:name IS NULL OR LOWER(t.name) LIKE LOWER(CONCAT('%', :name, '%'))) AND " +
                        "(:email IS NULL OR LOWER(t.email) LIKE LOWER(CONCAT('%', :email, '%'))) AND " +
                        "(:location IS NULL OR LOWER(t.location) LIKE LOWER(CONCAT('%', :location, '%'))) AND " +
                        "(:gender IS NULL OR t.gender = :gender) AND " +
                        "(:experience IS NULL OR t.experience = :experience) AND " +
                        "(:entityType IS NULL OR t.entityType = :entityType) AND " +
                        "(:isActive IS NULL OR t.isActive = :isActive) AND " +
                        "(:isVerified IS NULL OR t.isVerified = :isVerified)")
        List<Tutor> findTutorsWithAdvancedSearch(
                        @Param("name") String name,
                        @Param("email") String email,
                        @Param("location") String location,
                        @Param("gender") Tutor.Gender gender,
                        @Param("experience") Tutor.Experience experience,
                        @Param("entityType") Tutor.EntityType entityType,
                        @Param("isActive") Boolean isActive,
                        @Param("isVerified") Boolean isVerified);

        // Find by start time and end time (LocalDateTime)
        List<Tutor> findByStartTime(java.time.LocalDateTime startTime);

        List<Tutor> findByEndTime(java.time.LocalDateTime endTime);

        List<Tutor> findByStartTimeBetween(java.time.LocalDateTime start, java.time.LocalDateTime end);

        List<Tutor> findByEndTimeBetween(java.time.LocalDateTime start, java.time.LocalDateTime end);

        // Find by levels (multi-select)
        @Query("SELECT DISTINCT t FROM Tutor t JOIN t.levels l WHERE l = :level")
        List<Tutor> findByLevel(@Param("level") String level);

        @Query("SELECT DISTINCT t FROM Tutor t JOIN t.levels l WHERE l IN :levels")
        List<Tutor> findByLevelsIn(@Param("levels") List<String> levels);



        // Find tutors by category
        @Query("SELECT DISTINCT t FROM Tutor t JOIN t.categoryMappings tcm WHERE tcm.categoryId = :categoryId")
        List<Tutor> findTutorsByCategory(@Param("categoryId") Integer categoryId);

        // Find verified tutors accepting students in a category
        @Query("SELECT DISTINCT t FROM Tutor t JOIN t.categoryMappings tcm " +
                "WHERE tcm.categoryId = :categoryId " +
                "AND tcm.isAcceptingStudents = true " +
                "AND t.isVerified = true " +
                "AND t.isActive = true")
        List<Tutor> findVerifiedTutorsInCategory(@Param("categoryId") Integer categoryId);

        // Find by fee type
        List<Tutor> findByFeeType(FeeType feeType);

        // Find by fees range
        List<Tutor> findByFeesBetween(BigDecimal minFees, BigDecimal maxFees);
        List<Tutor> findByFeesLessThanEqual(BigDecimal maxFees);
        List<Tutor> findByFeesGreaterThanEqual(BigDecimal minFees);

        @Query("""
    SELECT DISTINCT t
    FROM Tutor t
    WHERE (:subject IS NULL OR :subject MEMBER OF t.subjects)
      AND (:mode IS NULL OR :mode MEMBER OF t.contactModes)
      AND (:standard IS NULL OR :standard MEMBER OF t.levels)
      AND (:location IS NULL OR LOWER(t.location) LIKE LOWER(CONCAT('%', :location, '%')))
""")
        List<Tutor> findTutorsWithFilters(
                @Param("subject") Tutor.Subject subject,
                @Param("mode") Tutor.ContactMode mode,
                @Param("standard") String standard,
                @Param("location") String location
        );

}
