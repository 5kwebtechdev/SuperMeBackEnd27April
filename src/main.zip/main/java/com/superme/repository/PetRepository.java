package com.superme.repository;

import com.superme.model.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PetRepository extends JpaRepository<Pet, Long> {
    Optional<Pet> findByPetName(String petName);

//    @Query("SELECT COUNT(p) FROM Pet p WHERE p.owner.id = :userId") // Use actual field name from Pet entity
//    int countByOwnerId(Long userId);
}