package com.superme.dto;

import lombok.Data;

@Data
public class CategoryIconUpdateRequest {
    private String category;
    private String oldValue;
    private String newValue;
    private String newIconPath;
}