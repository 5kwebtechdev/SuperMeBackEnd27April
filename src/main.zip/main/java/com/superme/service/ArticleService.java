package com.superme.service;

import com.superme.exception.BusinessException;
import com.superme.model.Article;
import com.superme.repository.ArticleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.superme.model.CoinTransaction;
import com.superme.model.User;
import com.superme.repository.CoinTransactionRepository;
import com.superme.repository.UserRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.security.Principal;

@Service
public class ArticleService {

    // Helper to extract User from Principal (moved from controller for reuse)
    public User getUserFromPrincipal(Principal principal) {
        String principalName = principal.getName();
        try {
            Long userId = Long.parseLong(principalName);
            return userRepository.findById(userId)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
        } catch (NumberFormatException e) {
            // Not a user ID, treat as username
            return userRepository.findByName(principalName)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
        }
    }

    @Autowired
    private ArticleRepository articleRepository;

    public List<Article> getAllArticles() {
        return articleRepository.findAll();
    }

    public Optional<Article> getArticleById(Long id) {
        return articleRepository.findById(id);
    }

    public Article markArticleAsRead(Long id) {
        Optional<Article> articleOpt = articleRepository.findById(id);
        if (articleOpt.isPresent()) {
            Article article = articleOpt.get();
            article.setStatus(Article.Status.READ); // Assuming Status.READ exists
            return articleRepository.save(article);
        }
        throw new BusinessException("Article not found");
    }

    ;

    @Autowired
    private CoinTransactionRepository coinTransactionRepository;

    @Autowired
    private UserRepository userRepository;

    // Overload: mark article as read and reward user with coins
    public Article markArticleAsRead(Long id, User user) {
        Optional<Article> articleOpt = articleRepository.findById(id);
        if (articleOpt.isPresent()) {
            Article article = articleOpt.get();
            article.setStatus(Article.Status.READ);
            Article saved = articleRepository.save(article);

            // Add 10 coins to user
            user.setCoins(user.getCoins() + 10);
            userRepository.save(user);

            // Record transaction
            CoinTransaction tx = CoinTransaction.builder().user(user).amount(10).type("ARTICLE_READ")
                    .description("Earned 10 coins for reading article: " + article.getTitle())
                    .timestamp(java.time.LocalDateTime.now()).build();
            coinTransactionRepository.save(tx);

            return saved;
        }
        throw new BusinessException("Article not found");
    }
}
