package com.superme.service;

import com.superme.exception.BusinessException;
import com.superme.exception.ResourceNotFoundException;
import com.superme.model.Profile;
import com.superme.model.User;
import com.superme.repository.ProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ProfileService {

    @Autowired
    private ProfileRepository profileRepository;

    /**
     * Create a child profile.
     */
    public Profile createProfile(Profile profile, User user) {
        profile.setUser(user); // Associate the profile with the user
        return profileRepository.save(profile);
    }

    /**
     * Get the child profile for a user.
     */
    public Optional<Profile> getProfile(User user) {
        return profileRepository.findByUser(user);
    }

    /**
     * Update the child profile.
     */
    public Profile updateProfile(Profile updatedProfile, User user) {
        Optional<Profile> existingProfileOptional = profileRepository.findByUser(user);

        if (existingProfileOptional.isPresent()) {
            Profile existingProfile = existingProfileOptional.get();
            existingProfile.setFullName(updatedProfile.getFullName());
            existingProfile.setPetName(updatedProfile.getPetName());
            existingProfile.setDob(updatedProfile.getDob());
            existingProfile.setGender(updatedProfile.getGender());
            existingProfile.setAvatar(updatedProfile.getAvatar());
            return profileRepository.save(existingProfile);
        } else {
            throw new ResourceNotFoundException("Profile not found for the user.");
        }
    }
}