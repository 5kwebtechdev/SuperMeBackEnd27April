package com.superme.service;

import com.superme.dto.LikeResponse;
import com.superme.dto.TutorsResponse;
import com.superme.enums.FeeType;
import com.superme.exception.ResourceNotFoundException;
import com.superme.model.Tutor;
import com.superme.repository.TutorRepository;
import com.superme.repository.LikeRepository;
import com.superme.model.Like;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class TutorService {

    @Autowired
    private TutorRepository tutorRepository;

    @Autowired
    private LikeRepository likeRepository;

    /**
     * Retrieves a list of tutors based on optional filter criteria.
     *
     * @param userId
     * @param subject  The subject to filter by (e.g., Mathematics, Science).
     * @param mode     The mode of teaching (e.g., In-Person, Online).
     * @param standard The standard/grade (e.g., Fifth, Sixth).
     * @param location The location or city (e.g., Mumbai, Delhi).
     * @return List of tutors matching the filters.
     */
    public List<TutorsResponse> getTutorsWithFilters(
            Long userId, String subject,
            String mode,
            String standard,
            String location) {

        Tutor.Subject subjectEnum =
                subject != null ? Tutor.Subject.valueOf(subject.toUpperCase()) : null;

        Tutor.ContactMode modeEnum =
                mode != null ? Tutor.ContactMode.valueOf(mode.toUpperCase()) : null;

        return tutorRepository.findTutorsWithFilters(
                        subjectEnum,
                        modeEnum,
                        standard,
                        location
                ).stream()
                .map(t -> mapToTutorsResponse(t, userId))
                .toList();
    }


    /**
     * Retrieves detailed information for a specific tutor by ID.
     * 
     * @param id The unique ID of the tutor.
     * @return The Tutor object if found, otherwise null.
     */
    public Tutor getTutorById(Long id) {
        Optional<Tutor> tutor = tutorRepository.findById(id);
        return tutor.orElse(null);
    }

    public LikeResponse likeTutor(Long tutorId, Long userId) {

        Tutor tutor = getTutorById(tutorId);
        if (tutor == null) {
            throw new ResourceNotFoundException("Tutor not found");
        }

        Optional<Like> existingLike =
                likeRepository.findByUserIdAndTutor(userId, tutor);

        boolean liked;
        if (existingLike.isPresent()) {
            likeRepository.delete(existingLike.get());
            liked = false;
        } else {
            Like like = new Like();
            like.setTutor(tutor);
            like.setUserId(userId);
            likeRepository.save(like);
            liked = true;
        }

        int totalLikes = likeRepository.countByTutor(tutor);
        return new LikeResponse(liked, totalLikes);
    }



    /**
     * Retrieves tutors available within a specific time range.
     */
    public List<TutorsResponse> getTutorsByTimeRange(
            Long userId, LocalDateTime start,
            LocalDateTime end) {

        return tutorRepository.findByStartTimeBetween(start, end)
                .stream()
                .map(t -> mapToTutorsResponse(t, userId))
                .toList();
    }


    /**
     * Retrieves tutors by a specific level (multi-select).
     */
    public List<Tutor> getTutorsByLevel(String level) {
        return tutorRepository.findByLevel(level);
    }

    /**
     * Retrieves tutors by multiple levels (multi-select).
     */
    public List<TutorsResponse> getTutorsByLevels(Long userId, List<String> levels) {

        if (levels == null || levels.isEmpty()) {
            return List.of();
        }

        return tutorRepository.findByLevelsIn(levels)
                .stream()
                .map(t -> mapToTutorsResponse(t, userId))
                .toList();
    }


    /**
     * Retrieves tutors by both time range and levels (combined filter).
     */
    public List<TutorsResponse> getTutorsByTimeAndLevels(
            Long userId, LocalDateTime start,
            LocalDateTime end,
            List<String> levels) {

        List<Tutor> byTime = tutorRepository.findByStartTimeBetween(start, end);
        List<Tutor> byLevels = tutorRepository.findByLevelsIn(levels);

        Set<Long> levelIds = byLevels.stream()
                .map(Tutor::getId)
                .collect(Collectors.toSet());

        return byTime.stream()
                .filter(t -> levelIds.contains(t.getId()))
                .map(t -> mapToTutorsResponse(t, userId))  // ✅ map entity → DTO
                .toList();
    }


    /**
     * Retrieves tutors by fee type.
     */
    public List<Tutor> getTutorsByFeeType(FeeType feeType) {
        return tutorRepository.findByFeeType(feeType);
    }

    /**
     * Retrieves tutors by fees range.
     */
    public List<Tutor> getTutorsByFeesRange(BigDecimal minFees, BigDecimal maxFees) {
        return tutorRepository.findByFeesBetween(minFees, maxFees);
    }

    /**
     * Retrieves tutors with fees less than or equal to a maximum value.
     */
    public List<Tutor> getTutorsByMaxFees(BigDecimal maxFees) {
        return tutorRepository.findByFeesLessThanEqual(maxFees);
    }

    /**
     * Retrieves tutors with fees greater than or equal to a minimum value.
     */
    public List<Tutor> getTutorsByMinFees(BigDecimal minFees) {
        return tutorRepository.findByFeesGreaterThanEqual(minFees);
    }

    public TutorsResponse mapToTutorsResponse(Tutor tutor, Long userId) {

        boolean likedByUser =
                userId != null &&
                        likeRepository.existsByUserIdAndTutor(userId, tutor);

        return TutorsResponse.builder()
                .id(tutor.getId())
                .name(tutor.getName())
                .headline(tutor.getHeadline())
                .age(tutor.getAge())
                .phone(tutor.getPhone())
                .email(tutor.getEmail())
                .gender(tutor.getGender())
                .qualification(tutor.getQualification())
                .experience(tutor.getExperience())
                .entityType(tutor.getEntityType())
                .entityName(tutor.getEntityName())
                .subjects(tutor.getSubjects())
                .location(tutor.getLocation())
                .addressLine(tutor.getAddressLine())
                .state(tutor.getState())
                .city(tutor.getCity())
                .pincode(tutor.getPincode())
                .profilePicUrl(tutor.getProfilePicUrl())
                .startTime(tutor.getStartTime())
                .endTime(tutor.getEndTime())
                .feeType(tutor.getFeeType())
                .fees(tutor.getFees())
                .levels(tutor.getLevels())
                .documentsVerificationUrl(tutor.getDocumentsVerificationUrl())
                .hourlyRate(tutor.getHourlyRate())
                .availability(tutor.getAvailability())
                .contactModes(tutor.getContactModes())
                .createdAt(tutor.getCreatedAt())
                .updatedAt(tutor.getUpdatedAt())
                .isActive(tutor.isActive())
                .isVerified(tutor.isVerified())
                .verificationNotes(tutor.getVerificationNotes())
                .adminNotes(tutor.getAdminNotes())
                .lastLoginAt(tutor.getLastLoginAt())
                .totalStudents(tutor.getTotalStudents())
                .rating(tutor.getRating())
                .totalReviews(tutor.getTotalReviews())
                .categoryMappings(tutor.getCategoryMappings())
                .categoryIds(tutor.getCategoryIds())
                .champsLiked(tutor.getChampsLiked())
                .likedByUser(likedByUser)
                .active(tutor.isActive())
                .verified(tutor.isVerified())
                .validForVerification(tutor.isValidForVerification())
                .build();
    }


}