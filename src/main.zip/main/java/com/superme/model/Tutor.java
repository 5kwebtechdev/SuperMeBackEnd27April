package com.superme.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.superme.enums.FeeType;
import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;
import java.math.BigDecimal;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

/**
 * Tutor entity for tutor management system.
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Tutor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    // NEW: headline for profile tagline
    @Column(name = "headline", length = 200)
    private String headline;

    @Column(name = "age", nullable = false)
    private Integer age;

    @Column(name = "phone", nullable = false, length = 20)
    private String phone;

    @Column(name = "email", nullable = false, unique = true, length = 150)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(name = "gender", nullable = false)
    private Gender gender;

    @Column(name = "qualification", nullable = false, length = 200)
    private String qualification;

    @Enumerated(EnumType.STRING)
    @Column(name = "experience", nullable = false)
    private Experience experience;

    @Enumerated(EnumType.STRING)
    @Column(name = "entity_type", nullable = false)
    private EntityType entityType;

    @Column(name = "entity_name", nullable = false, length = 200)
    private String entityName;

    @ElementCollection(targetClass = Subject.class, fetch = FetchType.EAGER)
    @Enumerated(EnumType.STRING)
    @CollectionTable(name = "tutor_subjects", joinColumns = @JoinColumn(name = "tutor_id"))
    @Column(name = "subject")
    @Builder.Default
    private List<Subject> subjects = new ArrayList<>();

    /**
     * Old high-level location label (you can keep for backwards compatibility / search).
     */
    @Column(name = "location", nullable = false, length = 300)
    private String location;

    // NEW – granular address fields for UI: Address / State / City / Pincode
    @Column(name = "address_line", length = 500)
    private String addressLine;   // House No, Street, Landmark

    @Column(name = "state", length = 100)
    private String state;

    @Column(name = "city", length = 100)
    private String city;

    @Column(name = "pincode", length = 20)
    private String pincode;

    @Column(name = "profile_pic_url", length = 500)
    private String profilePicUrl;

    @Column(name = "start_time")
    private LocalDateTime startTime;

    @Column(name = "end_time")
    private LocalDateTime endTime;

    @Enumerated(EnumType.STRING)
    @Column(name = "fee_type")
    private FeeType feeType;

    @Column(name = "fees", precision = 10, scale = 2)
    private BigDecimal fees;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "tutor_levels", joinColumns = @JoinColumn(name = "tutor_id"))
    @Column(name = "level")
    @Builder.Default
    private List<String> levels = new ArrayList<>();

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public List<String> getLevels() {
        return levels;
    }

    public void setLevels(List<String> levels) {
        this.levels = levels != null ? levels : new ArrayList<>();
    }

    @Column(name = "documents_verification_url", length = 500)
    private String documentsVerificationUrl;

    @Column(name = "hourly_rate", nullable = false, precision = 10, scale = 2)
    private BigDecimal hourlyRate;

    @ElementCollection(targetClass = Availability.class, fetch = FetchType.EAGER)
    @Enumerated(EnumType.STRING)
    @CollectionTable(name = "tutor_availability", joinColumns = @JoinColumn(name = "tutor_id"))
    @Column(name = "availability")
    @Builder.Default
    private List<Availability> availability = new ArrayList<>();

    @ElementCollection(targetClass = ContactMode.class, fetch = FetchType.EAGER)
    @Enumerated(EnumType.STRING)
    @CollectionTable(name = "tutor_contact_modes", joinColumns = @JoinColumn(name = "tutor_id"))
    @Column(name = "contact_mode")
    @Builder.Default
    private List<ContactMode> contactModes = new ArrayList<>();

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private Boolean isActive = true;

    @Column(name = "is_verified", nullable = false)
    @Builder.Default
    private Boolean isVerified = false;

    @Column(name = "verification_notes", length = 500)
    private String verificationNotes;

    @Column(name = "admin_notes", length = 1000)
    private String adminNotes;

    @Column(name = "last_login_at")
    private LocalDateTime lastLoginAt;

    @Column(name = "total_students", nullable = false)
    @Builder.Default
    private Integer totalStudents = 0;

    @Column(name = "rating", precision = 3, scale = 2)
    private BigDecimal rating;

    @Column(name = "total_reviews", nullable = false)
    @Builder.Default
    private Integer totalReviews = 0;

    @OneToMany(mappedBy = "tutor", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    @JsonIgnore
    @JsonManagedReference
    private List<Like> likes = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    @JoinColumn(name = "tutor_id")
    @Builder.Default
    private List<TutorCategoryMapping> categoryMappings = new ArrayList<>();

    public List<TutorCategoryMapping> getCategoryMappings() {
        return categoryMappings;
    }

    public void setCategoryMappings(List<TutorCategoryMapping> categoryMappings) {
        this.categoryMappings = categoryMappings;
    }

    public void addCategoryMapping(TutorCategoryMapping mapping) {
        if (this.categoryMappings == null) {
            this.categoryMappings = new ArrayList<>();
        }
        mapping.setTutorId(this.id);
        this.categoryMappings.add(mapping);
    }

    public void removeCategoryMapping(TutorCategoryMapping mapping) {
        if (this.categoryMappings != null) {
            this.categoryMappings.remove(mapping);
        }
    }

    @Transient
    public List<Integer> getCategoryIds() {
        List<Integer> ids = new ArrayList<>();
        if (this.categoryMappings != null) {
            for (TutorCategoryMapping mapping : this.categoryMappings) {
                ids.add(mapping.getCategoryId());
            }
        }
        return ids;
    }

    public boolean teachesCategory(Integer categoryId) {
        if (this.categoryMappings == null) {
            return false;
        }
        return this.categoryMappings.stream()
                .anyMatch(m -> m.getCategoryId().equals(categoryId));
    }

    public List<Like> getLikes() {
        return likes;
    }

    public void setLikes(List<Like> likes) {
        this.likes = likes;
    }

    @Transient
    public int getChampsLiked() {
        return (likes != null) ? likes.size() : 0;
    }

    public boolean isActive() {
        return isActive != null ? isActive : false;
    }

    public boolean isVerified() {
        return isVerified != null ? isVerified : false;
    }

    public void addSubject(Subject subject) {
        if (this.subjects == null) {
            this.subjects = new ArrayList<>();
        }
        if (!this.subjects.contains(subject)) {
            this.subjects.add(subject);
        }
    }

    public void removeSubject(Subject subject) {
        if (this.subjects != null) {
            this.subjects.remove(subject);
        }
    }

    public void addAvailability(Availability availability) {
        if (this.availability == null) {
            this.availability = new ArrayList<>();
        }
        if (!this.availability.contains(availability)) {
            this.availability.add(availability);
        }
    }

    public void removeAvailability(Availability availability) {
        if (this.availability != null) {
            this.availability.remove(availability);
        }
    }

    public void addContactMode(ContactMode contactMode) {
        if (this.contactModes == null) {
            this.contactModes = new ArrayList<>();
        }
        if (!this.contactModes.contains(contactMode)) {
            this.contactModes.add(contactMode);
        }
    }

    public void removeContactMode(ContactMode contactMode) {
        if (this.contactModes != null) {
            this.contactModes.remove(contactMode);
        }
    }

    public void incrementStudentCount() {
        this.totalStudents = (this.totalStudents != null ? this.totalStudents : 0) + 1;
    }

    public void decrementStudentCount() {
        this.totalStudents = Math.max(0, (this.totalStudents != null ? this.totalStudents : 0) - 1);
    }

    public void updateLastLogin() {
        this.lastLoginAt = LocalDateTime.now();
    }

    public boolean hasSubject(Subject subject) {
        return this.subjects != null && this.subjects.contains(subject);
    }

    public boolean isAvailable(Availability day) {
        return this.availability != null && this.availability.contains(day);
    }

    public boolean supportsContactMode(ContactMode mode) {
        return this.contactModes != null && this.contactModes.contains(mode);
    }

    // ENUMS (unchanged in structure)
    public enum Gender {
        MALE("Male"),
        FEMALE("Female"),
        OTHER("Other");

        private final String displayName;

        Gender(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    public enum Experience {
        FRESHER("Fresher"),
        PLUS_1("1+ Years"),
        PLUS_2("2+ Years"),
        PLUS_5("5+ Years"),
        PLUS_8("8+ Years"),
        PLUS_10("10+ Years");

        private final String displayName;

        Experience(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    public enum EntityType {
        SCHOOL("School"),
        COLLEGE("College"),
        TUITION("Tuition Center"),
        UNIVERSITY("University"),
        INSTITUTE("Training Institute"),
        SELF("Independent/Self"),
        INDIVIDUAL("Individual"),
        ACADEMY("Academy");


        private final String displayName;

        EntityType(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    public enum Subject {
        MATHEMATICS("Mathematics"),
        SCIENCE("Science"),
        ENGLISH("English"),
        SOCIAL_STUDIES("Social Studies"),
        PHYSICS("Physics"),
        CHEMISTRY("Chemistry"),
        BIOLOGY("Biology"),
        HISTORY("History"),
        GEOGRAPHY("Geography"),
        LITERATURE("Literature"),
        COMPUTER_SCIENCE("Computer Science"),
        ECONOMICS("Economics"),
        POLITICAL_SCIENCE("Political Science"),
        PSYCHOLOGY("Psychology"),
        PHILOSOPHY("Philosophy"),
        BUSINESS_STUDIES("Business Studies"),
        ACCOUNTING("Accounting"),
        HINDI("Hindi"),
        SANSKRIT("Sanskrit"),
        FRENCH("French"),
        GERMAN("German"),
        SPANISH("Spanish"),
        ART("Art & Craft"),
        MUSIC("Music"),
        DANCE("Dance"),
        PROGRAMMING("Programming"),
        WEB_DEVELOPMENT("Web Development"),
        DATA_SCIENCE("Data Science");

        private final String displayName;

        Subject(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    public enum Availability {
        MONDAY("Monday"),
        TUESDAY("Tuesday"),
        WEDNESDAY("Wednesday"),
        THURSDAY("Thursday"),
        FRIDAY("Friday"),
        SATURDAY("Saturday"),
        SUNDAY("Sunday"),
        WEEKDAYS("Weekdays"),
        WEEKENDS("Weekends"),
        FLEXIBLE("Flexible");

        private final String displayName;

        Availability(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    public enum ContactMode {
        VIDEO_CALL("Video Call"),
        PHONE_CALL("Phone Call"),
        IN_PERSON("In Person"),
        ONLINE_CHAT("Online Chat"),
        HYBRID("Hybrid (Online + Offline)");

        private final String displayName;

        ContactMode(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    @PrePersist
    protected void onCreate() {
        LocalDateTime now = LocalDateTime.now();
        this.createdAt = now;
        this.updatedAt = now;

        if (this.isActive == null) this.isActive = true;
        if (this.isVerified == null) this.isVerified = false;
        if (this.totalStudents == null) this.totalStudents = 0;
        if (this.totalReviews == null) this.totalReviews = 0;

        if (this.subjects == null) this.subjects = new ArrayList<>();
        if (this.availability == null) this.availability = new ArrayList<>();
        if (this.contactModes == null) this.contactModes = new ArrayList<>();
        if (this.levels == null) this.levels = new ArrayList<>();
        if (this.categoryMappings == null) this.categoryMappings = new ArrayList<>();
        if (this.likes == null) this.likes = new ArrayList<>();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public boolean isValidForVerification() {
        return this.name != null && !this.name.trim().isEmpty() &&
                this.email != null && !this.email.trim().isEmpty() &&
                this.phone != null && !this.phone.trim().isEmpty() &&
                this.qualification != null && !this.qualification.trim().isEmpty() &&
                this.subjects != null && !this.subjects.isEmpty() &&
                this.hourlyRate != null && this.hourlyRate.compareTo(BigDecimal.ZERO) > 0;
    }

    public boolean hasCompleteProfile() {
        return isValidForVerification() &&
                this.profilePicUrl != null && !this.profilePicUrl.trim().isEmpty() &&
                this.documentsVerificationUrl != null && !this.documentsVerificationUrl.trim().isEmpty() &&
                this.availability != null && !this.availability.isEmpty() &&
                this.contactModes != null && !this.contactModes.isEmpty();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Tutor tutor = (Tutor) o;

        if (id != null ? !id.equals(tutor.id) : tutor.id != null) return false;
        return email != null ? email.equals(tutor.email) : tutor.email == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (email != null ? email.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Tutor{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", headline='" + headline + '\'' +
                ", email='" + email + '\'' +
                ", experience=" + experience +
                ", entityType=" + entityType +
                ", totalStudents=" + totalStudents +
                ", rating=" + rating +
                ", isActive=" + isActive +
                ", isVerified=" + isVerified +
                '}';
    }
}
